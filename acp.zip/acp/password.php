<?php
$user = "root";
$pass = "1234";
?>