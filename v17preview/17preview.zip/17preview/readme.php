This is 1.7preview Release!
Enjoy!