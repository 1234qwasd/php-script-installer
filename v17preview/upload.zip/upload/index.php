<form action="upload.php" method="post" enctype="multipart/form-data">
    Select File
    <input type="file" name="dosya" />
    <input type="submit" value="Upload File" />
</form>
Your URL is http://websiteadress/yourfilename